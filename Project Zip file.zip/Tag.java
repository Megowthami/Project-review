package denote;


public class Tag
{
	 
	 private String tagname;

	 public String gettagname() 
		{
			return tagname;
		}
		public void setTagname(String tagname) 
		{
			this.tagname = tagname;
		}
		 
}