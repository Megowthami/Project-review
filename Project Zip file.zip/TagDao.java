package denote;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;

public class TagDao
{ 
     public String addTag(Tag tag)
     {
         String tagname = tag.gettagname();
         Connection con = null;
         PreparedStatement preparedStatement = null;         
         try
         {
             con = DBConnect.createConnection();
             String query = "insert into tag(tagname) values (?)";
             preparedStatement = con.prepareStatement(query);
             preparedStatement.setString(1, tagname);
            int i= preparedStatement.executeUpdate();             
             if (i!=0)  
             return "SUCCESS"; 
         }
         catch(SQLException e)
         {
            e.printStackTrace();
         }       
         return "Oops.. Something went wrong there..!"; 
     }
     
     
}