package denote;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 

 
public class TagServlet extends HttpServlet 
{ 
     public TagServlet() 
     {
     }
     protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     { 
         Tag tag = new Tag();       
         tag.setTagname(request.getParameter("tagname"));
        TagDao tagDao = new TagDao();
         String tagRegistered = tagDao.addTag(tag);         
         if(tagRegistered.equals("SUCCESS"))  
         {
            request.getRequestDispatcher("TagSuccess.jsp").forward(request, response);
         }
         else  
         {
            request.setAttribute("errMessage", tagRegistered);
            request.getRequestDispatcher("/TagError.jsp").forward(request, response);
         }
     }
    
}